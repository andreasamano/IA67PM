package BUSQUEDA;
import java.util.*;

public class BIPuzzle {
    static class Nodo {
        int[] estado;
        Nodo padre;
        int costo;

        public Nodo(int[] estado, Nodo padre, int costo) {
            this.estado = estado;
            this.padre = padre;
            this.costo = costo;
        }

        // Generar sucesores
        public List<Nodo> generarSucesores() {
            List<Nodo> sucesores = new ArrayList<>();
            int posVacio = -1;

            for (int i = 0; i < estado.length; i++) {
                if (estado[i] == 0) {
                    posVacio = i;
                    break;
                }
            }

            int[][] movimientos = {
                {1, 3},       // 0
                {0, 2, 4},    // 1
                {1, 5},       // 2
                {0, 4, 6},    // 3
                {1, 3, 5, 7}, // 4
                {2, 4, 8},    // 5
                {3, 7},       // 6
                {4, 6, 8},    // 7
                {5, 7}        // 8
            };

            for (int mov : movimientos[posVacio]) {
                int[] nuevoEstado = estado.clone();
                nuevoEstado[posVacio] = nuevoEstado[mov];
                nuevoEstado[mov] = 0;
                sucesores.add(new Nodo(nuevoEstado, this, this.costo + 1));
            }
            return sucesores;
        }

        public boolean esMeta() {
            int[] meta = {1,2,3,4,5,6,7,8,0};
            return Arrays.equals(estado, meta);
        }

        public void imprimirCamino() {
            if (padre != null) {
                padre.imprimirCamino();
            }
            imprimirEstado();
            System.out.println();
        }

        public void imprimirEstado() {
            for (int i = 0; i < estado.length; i++) {
                System.out.print((estado[i] == 0 ? " " : estado[i]) + " ");
                if ((i+1) % 3 == 0) System.out.println();
            }
        }
    }

    // ---------------- BFS ----------------
    public static Nodo bfs(int[] inicial) {
        Queue<Nodo> frontera = new LinkedList<>();
        Set<String> visitados = new HashSet<>();
        frontera.add(new Nodo(inicial, null, 0));

        while (!frontera.isEmpty()) {
            Nodo actual = frontera.poll();
            if (actual.esMeta()) return actual;

            visitados.add(Arrays.toString(actual.estado));
            for (Nodo sucesor : actual.generarSucesores()) {
                if (!visitados.contains(Arrays.toString(sucesor.estado))) {
                    frontera.add(sucesor);
                }
            }
        }
        return null;
    }

    // ---------------- DFS ----------------
    public static Nodo dfs(int[] inicial, int limite) {
        Stack<Nodo> frontera = new Stack<>();
        Set<String> visitados = new HashSet<>();
        frontera.push(new Nodo(inicial, null, 0));

        while (!frontera.isEmpty()) {
            Nodo actual = frontera.pop();
            if (actual.esMeta()) return actual;

            if (actual.costo > limite) continue;
            visitados.add(Arrays.toString(actual.estado));

            for (Nodo sucesor : actual.generarSucesores()) {
                if (!visitados.contains(Arrays.toString(sucesor.estado))) {
                    frontera.push(sucesor);
                }
            }
        }
        return null;
    }

    // ---------------- UCS ----------------
    public static Nodo ucs(int[] inicial) {
        PriorityQueue<Nodo> frontera = new PriorityQueue<>(Comparator.comparingInt(n -> n.costo));
        Set<String> visitados = new HashSet<>();
        frontera.add(new Nodo(inicial, null, 0));

        while (!frontera.isEmpty()) {
            Nodo actual = frontera.poll();
            if (actual.esMeta()) return actual;

            if (visitados.contains(Arrays.toString(actual.estado))) continue;
            visitados.add(Arrays.toString(actual.estado));

            for (Nodo sucesor : actual.generarSucesores()) {
                frontera.add(sucesor);
            }
        }
        return null;
    }

    
    public static void main(String[] args) {
        int[] estadoInicial = {1,2,3,4,0,6,7,5,8}; 

        // BFS
        System.out.println("=== BFS ===");
        long inicio = System.currentTimeMillis();
        Nodo solucionBFS = bfs(estadoInicial);
        long fin = System.currentTimeMillis();
        if (solucionBFS != null) {
            solucionBFS.imprimirCamino();
            System.out.println("Tiempo BFS: " + (fin - inicio) + " ms");
        }

        // DFS
        System.out.println("=== DFS ===");
        inicio = System.currentTimeMillis();
        Nodo solucionDFS = dfs(estadoInicial, 30);
        fin = System.currentTimeMillis();
        if (solucionDFS != null) {
            solucionDFS.imprimirCamino();
            System.out.println("Tiempo DFS: " + (fin - inicio) + " ms");
        }

        // UCS
        System.out.println("=== UCS ===");
        inicio = System.currentTimeMillis();
        Nodo solucionUCS = ucs(estadoInicial);
        fin = System.currentTimeMillis();
        if (solucionUCS != null) {
            solucionUCS.imprimirCamino();
            System.out.println("Tiempo UCS: " + (fin - inicio) + " ms");
        }
    }
}
