package BUSQUEDA;
import java.util.*;

public class Heuristica {
    static class Nodo {
        int[] estado;
        Nodo padre;
        int costo;   
        int heuristica; 

        public Nodo(int[] estado, Nodo padre, int costo) {
            this.estado = estado;
            this.padre = padre;
            this.costo = costo;
            this.heuristica = calcularHeuristica(estado);
        }

        
        private int calcularHeuristica(int[] estado) {
            int[] meta = {1,2,3,4,5,6,7,8,0};
            int h = 0;
            for (int i = 0; i < estado.length; i++) {
                if (estado[i] != 0 && estado[i] != meta[i]) {
                    h++; 
                }
            }
          
            if (estado[8] != 0) {
                h += 2;
            }
            return h;
        }

        public int f() {
            return costo + heuristica; 
        }

      
        public List<Nodo> generarSucesores() {
            List<Nodo> sucesores = new ArrayList<>();
            int posVacio = -1;
            for (int i = 0; i < estado.length; i++) {
                if (estado[i] == 0) {
                    posVacio = i;
                    break;
                }
            }

            int[][] movimientos = {
                {1, 3},      
                {0, 2, 4},    
                {1, 5},       
                {0, 4, 6},    
                {1, 3, 5, 7}, 
                {2, 4, 8},    
                {3, 7},       
                {4, 6, 8},    
                {5, 7}        
            };

            for (int mov : movimientos[posVacio]) {
                int[] nuevoEstado = estado.clone();
                nuevoEstado[posVacio] = nuevoEstado[mov];
                nuevoEstado[mov] = 0;
                sucesores.add(new Nodo(nuevoEstado, this, this.costo + 1));
            }
            return sucesores;
        }

        public boolean esMeta() {
            int[] meta = {1,2,3,4,5,6,7,8,0};
            return Arrays.equals(estado, meta);
        }

        public void imprimirCamino() {
            if (padre != null) padre.imprimirCamino();
            imprimirEstado();
            System.out.println();
        }

        public void imprimirEstado() {
            for (int i = 0; i < estado.length; i++) {
                System.out.print((estado[i] == 0 ? " " : estado[i]) + " ");
                if ((i+1) % 3 == 0) System.out.println();
            }
        }
    }

    public static Nodo aEstrella(int[] inicial) {
        PriorityQueue<Nodo> frontera = new PriorityQueue<>(Comparator.comparingInt(Nodo::f));
        Set<String> visitados = new HashSet<>();
        frontera.add(new Nodo(inicial, null, 0));

        while (!frontera.isEmpty()) {
            Nodo actual = frontera.poll();

            if (actual.esMeta()) return actual;

            if (visitados.contains(Arrays.toString(actual.estado))) continue;
            visitados.add(Arrays.toString(actual.estado));

            for (Nodo sucesor : actual.generarSucesores()) {
                frontera.add(sucesor);
            }
        }
        return null;
    }

    public static void main(String[] args) {
        int[] estadoInicial = {1,2,3,4,0,6,7,5,8};

        System.out.println("=== con heurística  ===");
        Nodo solucion = aEstrella(estadoInicial);
        if (solucion != null) {
            solucion.imprimirCamino();
           
        } else {
            System.out.println("No se encontró solución.");
        }
    }
}
